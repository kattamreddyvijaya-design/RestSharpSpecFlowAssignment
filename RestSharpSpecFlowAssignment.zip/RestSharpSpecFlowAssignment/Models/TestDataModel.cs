using Newtonsoft.Json;
using System.Collections.Generic;

namespace RestSharpSpecFlowSkeleton.Models
{
    public class TestDataModel
    {
        [JsonProperty("createOrder")]
        public OrderModel? CreateOrder { get; set; }

        [JsonProperty("createPet")]
        public PetModel? CreatePet { get; set; }

        [JsonProperty("updatePet")]
        public PetModel? UpdatePet { get; set; }
    }

    public class OrderModel
    {
        [JsonProperty("id")] public int Id { get; set; }
        [JsonProperty("petId")] public int PetId { get; set; }
        [JsonProperty("quantity")] public int Quantity { get; set; }
        [JsonProperty("shipDate")] public string? ShipDate { get; set; }
        [JsonProperty("status")] public string? Status { get; set; }
        [JsonProperty("complete")] public bool Complete { get; set; }
    }

    public class PetModel
    {
        [JsonProperty("id")] public int Id { get; set; }
        [JsonProperty("category")] public CategoryModel? Category { get; set; }
        [JsonProperty("name")] public string? Name { get; set; }
        [JsonProperty("photoUrls")] public List<string>? PhotoUrls { get; set; }
        [JsonProperty("tags")] public List<TagModel>? Tags { get; set; }
        [JsonProperty("status")] public string? Status { get; set; }
    }

    public class CategoryModel
    {
        [JsonProperty("id")] public int Id { get; set; }
        [JsonProperty("name")] public string? Name { get; set; }
    }

    public class TagModel
    {
        [JsonProperty("id")] public int Id { get; set; }
        [JsonProperty("name")] public string? Name { get; set; }
    }
}