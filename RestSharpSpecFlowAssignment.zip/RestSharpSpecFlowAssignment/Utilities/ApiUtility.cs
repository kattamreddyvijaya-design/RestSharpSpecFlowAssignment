using Newtonsoft.Json;
using NUnit.Framework;
using Polly;
using RestSharp;
using System.Collections.Generic;

namespace RestSharpSpecFlowSkeleton.Utilities;

public class ApiUtility
{
    private readonly ApiClient _apiClient;
    private readonly Reporter _reporter;


    public ApiUtility(ApiClient apiClient, Reporter reporter)
    {
        _apiClient = apiClient;
        _reporter = reporter;
    }

    public RestRequest CreateRequest(string endpoint, string methodName, 
        Dictionary<string, string>? headers = null,
        Dictionary<string, string>? parameters = null,
        string? jsonPayload = null)
    {
        var method = ToRestSharpMethod(methodName);
        var request = new RestRequest(endpoint, method);

        if (headers != null)
            foreach (var kv in headers) request.AddOrUpdateHeader(kv.Key, kv.Value);

        if (parameters != null)
            foreach (var kv in parameters) request.AddParameter(kv.Key, kv.Value);

        if (!string.IsNullOrWhiteSpace(jsonPayload))
        {
            request.AddStringBody(jsonPayload, DataFormat.Json);
        }

        return request;
    }

    public static Method ToRestSharpMethod(string methodName)
    {
        return methodName.Trim().ToUpperInvariant() switch
        {
            "GET" => Method.Get,
            "POST" => Method.Post,
            "PUT" => Method.Put,
            "PATCH" => Method.Patch,
            "DELETE" => Method.Delete,
            "HEAD" => Method.Head,
            "OPTIONS" => Method.Options,
            _ => throw new ArgumentException($"Unsupported HTTP method: {methodName}")
        };
    }

    public RestResponse Send(RestRequest request)
    {
        return _apiClient.Client.Execute(request);
    }

    public async Task<RestResponse> SendAsync(RestRequest request)
    {
        return await _apiClient.Client.ExecuteAsync(request);
    }

    //public async Task<T?> SendAsyncAs<T>(RestRequest request)
    //{
    //    var resp = await SendAsync(request);
    //    if (!resp.IsSuccessful) return default;
    //    return JsonConvert.DeserializeObject<T>(resp.Content ?? "");
    //}

    public async Task<RestResponse> SendWithRetryAsync(RestRequest request, int retries = 3)
    {
        var policy = Policy
            .Handle<Exception>()
            .WaitAndRetryAsync(retries, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)));
        return await policy.ExecuteAsync(async () => await _apiClient.Client.ExecuteAsync(request));
    }

    public void ValidateStatusCode(RestResponse response, int expectedStatusCode)
    {
        var actualStatusCode = (int) response.StatusCode;
        bool flag = expectedStatusCode == actualStatusCode;
        if (flag) { Assert.True(flag, $"Actual status code is same as expected: {actualStatusCode}"); }
        else
        {
            _reporter.Info($"Expected status {expectedStatusCode}, got {(int)response.StatusCode} ({response.StatusDescription}). Body: {response.Content}");
            throw new Exception($"Expected status {expectedStatusCode}, got {(int)response.StatusCode} ({response.StatusDescription}). Body: {response.Content}");
        }
    }

    public void ValidateResponseMatchesPayload(string expectedPayloadJson, string actualResponseJson)
    {
        bool flag = (RestSharpSpecFlowSkeleton.Utilities.JsonUtil.JsonEquals(expectedPayloadJson, actualResponseJson));
        if (flag) { Assert.True(flag, $"Actual response JSON is as expected"); }
        else
        {
            _reporter.Info($"Response JSON does not match expected subset. \nExpected: {expectedPayloadJson} \nActual: {actualResponseJson}");
            throw new Exception($"Response JSON does not match expected subset. \nExpected: {expectedPayloadJson} \nActual: {actualResponseJson}");
        }
    }
}


