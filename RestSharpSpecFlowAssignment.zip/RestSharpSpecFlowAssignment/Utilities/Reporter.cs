using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;

namespace RestSharpSpecFlowSkeleton.Utilities;

public class Reporter
{
    private static ExtentReports? _extent;
    private static ExtentTest? _current;

    private static string FindSolutionRoot()
    {
        var d = new DirectoryInfo(AppContext.BaseDirectory);
        while (d != null && !d.GetFiles("*.sln").Any()) { d = d.Parent; }
        return d?.FullName ?? AppContext.BaseDirectory;
    }

    public static void Init()
    {
        var root = FindSolutionRoot();
        var dir = Path.Combine(root, "Artifacts");
        Directory.CreateDirectory(dir);

        var html = new ExtentHtmlReporter(Path.Combine(dir, "Report.html"));
        _extent = new ExtentReports();
        _extent.AttachReporter(html);

        _extent.Flush();
    }

    public static void StartScenario(string name) => _current = _extent?.CreateTest(name);
    public  void Info(string msg) => _current?.Info(msg);
    public  void Pass(string msg) => _current?.Pass(msg);
    public  void Fail(string msg) => _current?.Fail(msg);

    public static void Flush()
    {
        try { _extent?.Flush(); }
        catch { Console.WriteLine("Reporter Flush Skipped"); }
    } 
}
