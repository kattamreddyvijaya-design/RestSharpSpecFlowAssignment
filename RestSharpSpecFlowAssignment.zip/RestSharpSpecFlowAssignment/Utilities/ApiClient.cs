using RestSharp;
using RestSharp.Authenticators;

namespace RestSharpSpecFlowSkeleton.Utilities;

public class ApiClient
{
    public string BaseUrl { get; }
    public RestClient Client { get; private set; }

    public ApiClient(string baseUrl)
    {
        BaseUrl = baseUrl.TrimEnd('/');
        var options = new RestClientOptions(BaseUrl)
        {
            ThrowOnAnyError = false,
            MaxTimeout = 60000
        };
        Client = new RestClient(options);
    }

    public void UseNoAuth()
    {
        // Create a new client without authenticator
        var options = new RestClientOptions(BaseUrl)
        {
            ThrowOnAnyError = false,
            MaxTimeout = 60000,
            Authenticator = null
        };
        Client = new RestClient(options);
    }

    public void UseBasicAuth(string username, string password)
    {
        var options = new RestClientOptions(BaseUrl)
        {
            ThrowOnAnyError = false,
            MaxTimeout = 60000,
            Authenticator = new HttpBasicAuthenticator(username, password)
        };
        Client = new RestClient(options);
    }

    public void UseHeaderAuth(string key, string value)
    {
        var options = new RestClientOptions(BaseUrl)
        {
            ThrowOnAnyError = false,
            MaxTimeout = 60000
        };
        Client = new RestClient(options);
        Client.AddDefaultHeader(key, value);
    }
}