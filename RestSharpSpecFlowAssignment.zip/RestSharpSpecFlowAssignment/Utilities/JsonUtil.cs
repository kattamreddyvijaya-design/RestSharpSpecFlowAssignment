using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharpSpecFlowSkeleton.Models;

namespace RestSharpSpecFlowSkeleton.Utilities;

public static class JsonUtil
{
    private static string GetSolutionRoot()
    {
        var dir = AppContext.BaseDirectory;
        while (!string.IsNullOrEmpty(dir) && Directory.GetFiles(dir, "*.sln").Length == 0)
        {
            var parent = Directory.GetParent(dir);
            if (parent == null) break;
            dir = parent.FullName;
        }
        return dir ?? AppContext.BaseDirectory;
    }

    private static string GetFilePath(string relativePath)
    {
        return Path.Combine(GetSolutionRoot(), "TestData/" + relativePath);
    }

    public static string ReadJsonFile(string relativePath)
    {
        var fullPath = GetFilePath(relativePath);
        if (!File.Exists(fullPath))
            throw new FileNotFoundException($"File not found at: {fullPath}");
        return File.ReadAllText(fullPath);
    }

    public static string ReadJsonBlock(string relativePath, string block)
    {
        var json = ReadJsonFile(relativePath);
        var root = JObject.Parse(json);
        var token = root[block];
        if (token == null)
            throw new Exception($"Block '{block}' not found in {relativePath}");
        return token.ToString(Formatting.None);
    }

    public static TestDataModel ReadAll(string relativePath)
    {
        return JsonConvert.DeserializeObject<TestDataModel>(ReadJsonFile(relativePath))!;
    }

    public static bool JsonEquals(string expectedJson, string actualJson)
    {
        var expected = JToken.Parse(expectedJson);
        var actual = JToken.Parse(actualJson);

        bool IsSubset(JToken expectedToken, JToken actualToken)
        {
            if (expectedToken is JObject eObj && actualToken is JObject aObj)
            {
                foreach (var prop in eObj)
                {
                    if (!aObj.TryGetValue(prop.Key, out var aVal)) return false;
                    if (!IsSubset(prop.Value, aVal)) return false;
                }
                return true;
            }
            if (expectedToken is JArray eArr && actualToken is JArray aArr)
            {
                foreach (var eItem in eArr)
                {
                    if (!aArr.Any(aItem => IsSubset(eItem, aItem))) return false;
                }
                return true;
            }
            if (DateTime.TryParse(expectedToken.ToString(), out DateTime date))
            {
                if (Convert.ToDateTime(actualToken).Date == Convert.ToDateTime(expectedToken).Date) return true ;
            }

            return JToken.DeepEquals(expectedToken, actualToken);
        }
        return IsSubset(expected, actual);
    }
}
