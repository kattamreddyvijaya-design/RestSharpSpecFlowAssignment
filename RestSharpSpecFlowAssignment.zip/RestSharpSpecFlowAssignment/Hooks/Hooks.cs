﻿using BoDi;
using TechTalk.SpecFlow;
using RestSharpSpecFlowSkeleton.Utilities;

namespace RestSharpSpecFlowSkeleton.Hooks;

[Binding]
public class Hooks
{
    private readonly IObjectContainer _container;
    private readonly Reporter _reporter;
    public Hooks(IObjectContainer container) => _container = container;

    [BeforeTestRun]
    public static void BeforeTestRun() => Reporter.Init();

    [AfterTestRun]
    public static void AfterTestRun() => Reporter.Flush();

    [BeforeScenario]
    public void BeforeScenario(ScenarioContext ctx)
    {
        // appsettings.json → baseUrl
        var baseUrl = (string)Newtonsoft.Json.Linq.JObject
            .Parse(File.ReadAllText("appsettings.json"))["baseUrl"]!;
        var apiClient = new ApiClient(baseUrl);
        var apiUtility = new ApiUtility(apiClient, _reporter);
        _container.RegisterInstanceAs(apiClient);
        _container.RegisterInstanceAs(apiUtility);

        Reporter.StartScenario(ctx.ScenarioInfo.Title);
    }

    [AfterScenario]
    public void AfterScenario() => Reporter.Flush(); 
}