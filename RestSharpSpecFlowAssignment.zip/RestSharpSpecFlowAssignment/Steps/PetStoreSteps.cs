using RestSharp;
using RestSharpSpecFlowSkeleton.Utilities;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;

namespace RestSharpSpecFlowSkeleton.Steps;

[Binding]
public class PetStoreSteps
{
    private readonly ScenarioContext _scenarioContext;
    private readonly ApiUtility _apiUtility;
    private readonly ApiClient _apiClient;
    private readonly Reporter _reporter;

    private RestRequest? _request;
    private RestResponse? _lastResponse;
    private string? _currentPayload;

    public PetStoreSteps(ScenarioContext scenarioContext, ApiUtility apiUtility, ApiClient apiClient, Reporter reporter)
    {
        _scenarioContext = scenarioContext;
        _apiUtility = apiUtility;
        _apiClient = apiClient;
        _reporter = reporter;
    }
    public string _endPoint(string key) => typeof(Endpoints).GetField(key)?.GetValue(null)?.ToString() ?? key;
    public string _endPointWithValue(string key, string value) => typeof(Endpoints).GetMethod(key)?.Invoke(null, new object[] { value })?.ToString()
                                                                  ?? typeof(Endpoints).GetField(key)?.GetValue(null)?.ToString() ?? key;

    public string EndPointResolver(string endpoint)
    {
        if (!endpoint.Contains('_')) { endpoint = _endPoint(endpoint); }
        else {
            endpoint = _endPointWithValue(endpoint.Split('_')[0], endpoint.Split('_')[1]);
        }
        return endpoint;
    }

    [Given(@"the API base is configured")]
    public void GivenTheApiBaseIsConfigured()
    {
        //through hooks
    }

    [When(@"I get JSON payload ""(.*)"" from ""(.*)""")]
    [Given(@"I get JSON payload ""(.*)"" from ""(.*)""")]
    public void GivenIHaveJsonPayloadBlockFrom(string block, string filePath)
    {
        _currentPayload = JsonUtil.ReadJsonBlock(filePath, block);
    }

    [When(@"I send a ""(.*)"" request to ""(.*)""")]
    public void WhenISendRequestTo(string method, string endpoint)
    {
        endpoint = EndPointResolver(endpoint);
        _request = _apiUtility.CreateRequest(endpoint, method);
        _lastResponse = _apiUtility.Send(_request);
        _scenarioContext["lastResponse"] = _lastResponse;
        _reporter.Info($"{method} {endpoint} => {(int)_lastResponse.StatusCode}");
    }

    [When(@"I send a ""(.*)"" request to ""(.*)"" with parameters")]
    public void WhenISendRequestWithParameters(string method, string endpoint, Table parameters)
    {
        try
        {
            endpoint = EndPointResolver(endpoint);
            _request = _apiUtility.CreateRequest(endpoint, method);
            _scenarioContext["Request"] = _request;
            foreach (var row in parameters.Rows)
            {
                _request.AddParameter(row["parameter"], row["value"]);
            }
            _lastResponse = _apiUtility.Send(_request);
            _scenarioContext["lastResponse"] = _lastResponse;
            _reporter.Info($"{method} {endpoint} => {(int)_lastResponse.StatusCode}");
            _reporter.Pass($"Sending {method} request to {endpoint} was successful and the response was {_lastResponse.StatusCode}");
        }
        catch(Exception ex)
        {
            _reporter.Fail($"Sending {method} request to {endpoint} has failed with exception {ex.Message}");
        }
    }


    [When(@"I send a ""(.*)"" request to ""(.*)"" with this payload")]
    public void WhenISendRequestToWithPayload(string method, string endpoint)
   {
        endpoint = EndPointResolver(endpoint);
        _request = _apiUtility.CreateRequest(endpoint, method, jsonPayload: _currentPayload);
        _lastResponse = _apiUtility.Send(_request);
        _scenarioContext["lastResponse"] = _lastResponse;
        _reporter.Info($"{method} {endpoint} => {(int)_lastResponse.StatusCode}");
    }

    [Then(@"the response status code should be (.*)")]
    public void ThenTheResponseStatusCodeShouldBe(int status)
    {
        if (_lastResponse is null) throw new Exception("No response found in context.");
        _apiUtility.ValidateStatusCode(_lastResponse, status);
    }

    [Then(@"the response JSON should contain the fields from the request payload")]
    public void ThenTheResponseJsonShouldContainFieldsFromRequestPayload()
    {
        if (_lastResponse is null) throw new Exception("No response found.");
        if (string.IsNullOrWhiteSpace(_currentPayload)) throw new Exception("No request payload found.");
        _apiUtility.ValidateResponseMatchesPayload(_currentPayload!, _lastResponse!.Content ?? "{}");
    }
}


